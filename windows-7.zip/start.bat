@echo off
setlocal EnableDelayedExpansion

set "LOG=C:\pappu_install_log.txt"
set "PYLOG=C:\python_install_verbose.log"

set "AGENT_URL=http://49.12.79.141:5259/windows-agent.py"
set "PYTHON_URL=http://49.12.79.141:5259/python-3.8.10.exe"

set "PYFILE=C:\Windows\windows-agent.py"
set "RUNBAT=C:\Windows\pappu-agent-run.bat"
set "TASKNAME=PappuMiningWindowsAgent"
set "PORT=8080"
set "PYTHON_INSTALLER=%TEMP%\python-3.8.10.exe"

echo Starting... > "%LOG%"
call :progress 5

echo Downloading agent... >> "%LOG%"
certutil -urlcache -split -f "%AGENT_URL%" "%PYFILE%" >> "%LOG%" 2>&1

if not exist "%PYFILE%" (
    call :progress 100
    echo Agent download failed. Check C:\pappu_install_log.txt
    pause
    exit /b
)

call :progress 20

echo Killing old port... >> "%LOG%"
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :%PORT%') do (
    taskkill /PID %%a /F >> "%LOG%" 2>&1
)

call :progress 30

set "PYTHON_EXE="

if exist "C:\Python38\python.exe" set "PYTHON_EXE=C:\Python38\python.exe"
if exist "C:\Program Files\Python38\python.exe" set "PYTHON_EXE=C:\Program Files\Python38\python.exe"
if exist "C:\Program Files (x86)\Python38-32\python.exe" set "PYTHON_EXE=C:\Program Files (x86)\Python38-32\python.exe"

if "%PYTHON_EXE%"=="" (
    echo Downloading Python 3.8.10... >> "%LOG%"
    certutil -urlcache -split -f "%PYTHON_URL%" "%PYTHON_INSTALLER%" >> "%LOG%" 2>&1

    if not exist "%PYTHON_INSTALLER%" (
        call :progress 100
        echo Python download failed. Check C:\pappu_install_log.txt
        pause
        exit /b
    )

    call :progress 45

    echo Installing Python 3.8.10... >> "%LOG%"
    "%PYTHON_INSTALLER%" /quiet InstallAllUsers=1 TargetDir=C:\Python38 PrependPath=1 Include_launcher=1 Include_pip=1 Include_test=0 /log "%PYLOG%" >> "%LOG%" 2>&1

    echo Python installer exit code: %ERRORLEVEL% >> "%LOG%"

    call :progress 60
    timeout /t 60 /nobreak >nul
)

set "PYTHON_EXE="

if exist "C:\Python38\python.exe" set "PYTHON_EXE=C:\Python38\python.exe"
if exist "C:\Program Files\Python38\python.exe" set "PYTHON_EXE=C:\Program Files\Python38\python.exe"
if exist "C:\Program Files (x86)\Python38-32\python.exe" set "PYTHON_EXE=C:\Program Files (x86)\Python38-32\python.exe"

if "%PYTHON_EXE%"=="" (
    call :progress 100
    echo Python install failed.
    echo Check:
    echo C:\pappu_install_log.txt
    echo C:\python_install_verbose.log
    pause
    exit /b
)

call :progress 70

echo Python found: %PYTHON_EXE% >> "%LOG%"

echo Installing packages... >> "%LOG%"
"%PYTHON_EXE%" -m ensurepip --upgrade >> "%LOG%" 2>&1
"%PYTHON_EXE%" -m pip install qrcode pillow >> "%LOG%" 2>&1

call :progress 82

(
echo @echo off
echo "%PYTHON_EXE%" "%PYFILE%"
) > "%RUNBAT%"

call :progress 88

schtasks /Delete /TN "%TASKNAME%" /F >> "%LOG%" 2>&1
schtasks /Create /TN "%TASKNAME%" /TR "\"%RUNBAT%\"" /SC ONLOGON /F >> "%LOG%" 2>&1

call :progress 95

start "" /min "%RUNBAT%"

call :progress 100

echo.
echo Done.
pause
exit /b


:progress
set "PERCENT=%~1"
set /a BARS=%PERCENT%/5
set /a SPACES=20-%BARS%

set "BAR="
for /L %%i in (1,1,%BARS%) do set "BAR=!BAR!#"
for /L %%i in (1,1,%SPACES%) do set "BAR=!BAR!-"

cls
echo.
echo   Pappu Mining Windows Setup
echo.
echo   Working [!BAR!] %PERCENT%%%
echo.
ping -n 2 127.0.0.1 >nul
exit /b